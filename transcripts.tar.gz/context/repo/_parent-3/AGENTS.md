# AGENTS.md

Your operating manual for this workspace, written by you. Your main instructions cover how you work in general. This file is where you keep the specific, durable lessons and conventions you pick up as you work, the kind of thing you'd want a future session to know. It's not about the user (that goes in `USER.md` and your memory) or your personality (that's `SOUL.md`); it's about how you get work done here.

## Conventions
Add an entry whenever you work something out worth keeping, for example:
- a convention you've settled on ("keep data exports in `workspace/exports/` and clean them up monthly")
- a tool or site quirk worth remembering ("site X hides its form behind a cookie banner; dismiss it first")
- a workflow that worked, or a mistake not to repeat

It starts empty and is meant to grow slowly. Don't pad it; a short, accurate file beats a long, stale one.

## make.fun leaderboard parsing — match full ID, never prefix
- Submission IDs are UUIDv7: they ALL start with `01a1f...` (timestamp prefix). Matching by an 8-char prefix matches the wrong entries (2026-11-21 07:10 watch nearly reported a false #56 paid-zone entry for gta6-01). Always match the full `submission_id` or the `handle` (`<user>`) when reading a leaderboard.

## One-shot watchers: use cron, never bare /etc systemd units
- 2026-11-04 Digital Bomb: watcher service in /etc/systemd/system died before its 13:30 trigger because a VM replacement wiped /etc (home dir persists, /etc does not). The script in ~/workspace survived but nothing ran it. For any one-shot timed trigger, use a runtime-managed cron runonce that does the work itself (or recreates the service at fire time) — cron jobs survive VM replacement, /etc units do not.

## PERMANENT RULES — make.fun bounties (user, 2026-11-20 17:51 WIB, made permanent 17:59 WIB)

These rules govern ALL make.fun work — new bounties, iterations, and the hourly watch — until the user changes them:

1. **Maximize every already-submitted bounty until it reaches a paid top rank.** A submitted entry is never "done" while its competition is still open and a stronger version can still be submitted before the deadline.
2. **Before any submit, study the leaderboard top rank 1–50 first** — live board, actual top artifacts viewed (not just titles), score decomposition understood 100%: why the top wins, which component is beatable, saturation/tie-break state. No submit before this recon is complete.
3. **New bounties are worked with rules 1 and 2 as well** — recon-first, then build to beat the paid threshold, not just to pass validation.
4. **Use the internet freely.** When stuck or when a technique is missing, research via Google/web — lessons from the internet are a normal part of recon and build, not an exception.
5. **Chase every submitted bounty to top rank 1–50** (the paid places; where a competition pays beyond 50, e.g. top 100, the paid line is the target).
6. **An entry that is ALREADY inside the paid top zone is NOT to be disturbed** (user rule, 2026-11-21 00:25 WIB; AMENDED by user 2026-11-21 11:14 WIB) — freeze it as it stands, with ONE exception: if recon proves a new entry would be 100% better (decisively stronger, not marginal) than the standing paid entry, a resubmit may be prepared — but the user must ALWAYS be told first and his go-ahead waited for before anything is submitted over a paid entry. No silent resubmit over a paid entry, ever. Rules 1 and 5 apply freely only to entries still OUTSIDE the paid zone.
7. **Combined standing order (user, 2026-11-21 00:49 WIB, declared permanent):** chase every submitted entry that is still outside the paid zone using ALL capabilities and lessons learned so far; when a technique or knowledge is missing, research it on the internet (rule 4) instead of stalling. The paid-zone protection (rule 6, as amended) always wins over the chase.
8. **Hourly execution (user, 2026-11-21 11:14 WIB, permanent):** rules 1–3 above are run EVERY HOUR by the bounty watch — newest bounties reconned first then worked toward the paid top 1–50, every open entry outside the paid zone maximized, paid-zone entries handled only per rule 6.

Guards that stay in force alongside these rules:
- Skip anything paid (submit fees, paid accounts, wallet top-ups) — never pay anything.
- Force_Last guard: never burn a round on a rebuild without a concrete improvement plan from recon — a weaker new entry displaces the standing one.
- A specific stop/release order from the user for a named bounty overrides these rules for that bounty.
- The on-chain safety rails (MEMORY.md, user 2026-11-18) still win over everything here.

## PERMANENT RULES — make.fun error prevention (user, 2026-11-22 17:47 WIB)

Ordered by the user after the 2026-11-21/22 sweep mistakes ("perbaiki kesalahan dan buat jadi skill dan aturan permanen buat lo kedepan biar gak salah lagi"). Full playbook: skill `makefun-error-lessons` (~/workspace/custom-skills/makefun-error-lessons/SKILL.md). These bind the main agent and the hourly watch (also embedded in the watch cron body as E1–E6):

1. **Weak evidence never replaces a paid entry.** An internal tournament win, a feature checklist, or artifact-pattern matching is never proof a new version beats the standing entry on the real judge (Feel Awe v3 destroyed a #29 paid entry, scored 767 vs 856). A paid-zone replacement proposal must name one concrete scored component with live top-1–50 evidence, and disclose that replacement destroys the standing entry. No proof → recommend KEEP.
2. **Iterations need a named scored gap, not more features.** Four consecutive "more complete" iterations regressed on the real judge (News 21 v9, Feel Awe v3, Stealth v2, Stealth v4). Dev-board deltas <5 points are judge noise. After 2 consecutive regressions on one competition, stop iterating it without a genuinely new mechanism; record the stop in the state file.
3. **Intake is not acceptance.** Never report an entry as "in" until the status endpoint shows it judged/scored AND it is on the live leaderboard; re-check the status endpoint later the same day (entries get rejected after clean intakes — GTA 6 v9). Correct a premature report immediately when the verdict lands.
4. **All entry code is written fresh in a bundled session, at its final path.** No copying a previous version's directory, no cp/mv of code into an entry repo, no re-typing code seen in a tool result or sibling entry (News 21 v10 rejected; News 22 v3 first check failed). Reading a prior version's DATA is fine; reading its CODE is contamination. Entrypoint stubs are authored fresh from a spec, same as real code.
5. **Verify before relaying.** Watch/worker claims about money, standings, blockers, or account state are leads, not facts — re-verify against the live API or the actual file/commit first (false API-key alarm, false README-missing claim, wrong signup column). Read the board's `rank_key` and score decomposition before quoting any number.
6. **Read the checker before guessing at a gate.** If a kit check fails twice on the same gate, read its implementation in the kit CLI before another fix attempt (Tiny Stack v2: four fixer sessions wasted; the code proved the 26-byte target impossible in minutes). Do the floor/ceiling math before chasing any threshold; close provably unreachable targets with the proof in the state file.
